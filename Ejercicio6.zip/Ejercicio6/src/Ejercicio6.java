import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ejercicio6 extends JFrame{
    private JButton botonD4;
    private JPanel panel;
    private JButton botonD6;
    private JButton botonD8;
    private JButton botonD10;
    private JButton botonD12;
    private JButton botonD20;
    private JButton botonD100;
    private JLabel valor;

    public Ejercicio6(){
        super("Dados");
        setContentPane(panel);
        botonD4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d4() +"]");
            }
        });

        botonD6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d6() +"]");
            }
        });

        botonD8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d8() +"]");
            }
        });

        botonD10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                valor.setText("[" +d10() +"]");
            }
        });

        botonD12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d12() +"]");
            }
        });

        botonD20.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d20() +"]");
            }
        });

        botonD100.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                valor.setText("[" +d100() +"]");
            }
        });



        botonD4.setIcon(new ImageIcon("dados/d4.png"));
        botonD6.setIcon(new ImageIcon("dados/d6.png"));
        botonD8.setIcon(new ImageIcon("dados/D8.png"));
        botonD10.setIcon(new ImageIcon("dados/D10.png"));
        botonD12.setIcon(new ImageIcon("dados/D12.png"));
        botonD20.setIcon(new ImageIcon("dados/d20.png"));
        botonD100.setIcon(new ImageIcon("dados/100.png"));


    }

    public static class Main{
        public static void main(String[] args){
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    JFrame frame = new Ejercicio6();
                    frame.setSize(1200, 400);
                    frame.setVisible(true);
                }
            });
        }
    }

    private int d4() {
        int valor = (int) Math.floor(Math.random()*4-1+1)+1;

        return valor;
    }

    private int d6() {
        int valor = (int) Math.floor(Math.random()*6-1+1)+1;

        return valor;
    }

    private int d8() {
        int valor = (int) Math.floor(Math.random()*8-1+1)+1;

        return valor;
    }

    private int d10() {
        int valor = (int) Math.floor(Math.random()*10-1+1)+1;

        return valor;
    }

    private int d12() {
        int valor = (int) Math.floor(Math.random()*12-1+1)+1;

        return valor;
    }

    private int d20() {
        int valor = (int) Math.floor(Math.random()*20-1+1)+1;

        return valor;
    }

    private int d100() {
        int valor = (int) Math.floor(Math.random()*100-1+1)+1;

        return valor;
    }
}
